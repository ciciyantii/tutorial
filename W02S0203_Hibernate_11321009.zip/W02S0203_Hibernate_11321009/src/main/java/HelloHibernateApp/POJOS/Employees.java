package HelloHibernateApp.POJOS;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Employees {
    private int empNo;
    private String firstName, lastName, gender;
    private Date birthDate, hireDate;
    private Set<Titles> listOfTitles = new HashSet<Titles>();

    public Employees() {}

    // Getter dan Setter untuk empNo
    public int getEmpNo() {
        return empNo;
    }

    public void setEmpNo(int empNo) {
        this.empNo = empNo;
    }

    // Getter dan Setter untuk firstName
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    // Getter dan Setter untuk lastName
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    // Getter dan Setter untuk gender
    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    // Getter dan Setter untuk birthDate
    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    // Getter dan Setter untuk hireDate
    public Date getHireDate() {
        return hireDate;
    }

    public void setHireDate(Date hireDate) {
        this.hireDate = hireDate;
    }

    // Getter dan Setter untuk listOfTitles
    public Set<Titles> getListOfTitles() {
        return listOfTitles;
    }

    public void setListOfTitles(Set<Titles> listOfTitles) {
        this.listOfTitles = listOfTitles;
    }
}
