
package HelloHibernateApp.POJOS;

import java.io.Serializable;
import java.util.Date;

public class Titles implements Serializable {
    private static final long serialVersionUID = 1L; // Menambahkan serialVersionUID
    private String title;
    private Date fromDate, toDate;
    private Employees emp;

    public Titles() {}

    // Getter dan Setter untuk title
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    // Getter dan Setter untuk fromDate
    public Date getFromDate() {
        return fromDate;
    }

    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }

    // Getter dan Setter untuk toDate
    public Date getToDate() {
        return toDate;
    }

    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }

    // Getter dan Setter untuk emp
    public Employees getEmp() {
        return emp;
    }

    public void setEmp(Employees emp) {
        this.emp = emp;
    }
}
