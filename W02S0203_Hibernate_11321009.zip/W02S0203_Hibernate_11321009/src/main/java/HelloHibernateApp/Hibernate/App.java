package HelloHibernateApp.Hibernate;

import org.hibernate.Session;
import org.hibernate.query.Query;
import HelloHibernateApp.POJOS.Employees;
import HelloHibernateApp.POJOS.Titles;
import HelloHibernateApp.Utils.HibernateUtil;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class App {
    public static void main(String[] args) {
        // Menampilkan sepuluh data pegawai
        showEmployee(HibernateUtil.getSessionFactory().openSession());

        // Menampilkan detail pegawai dengan id 
        showEmpTitles(HibernateUtil.getSessionFactory().openSession(), 1002);

        // Menyisipkan data pegawai
        insertEmployee(HibernateUtil.getSessionFactory().openSession());

        // Memperbarui data pegawai berdasarkan EmpNo
        updateEmployee(HibernateUtil.getSessionFactory().openSession());

        // Menghapus data pegawai berdasarkan EmpNo
        deleteEmployee(HibernateUtil.getSessionFactory().openSession());
    }

    public static void showEmployee(Session sess) {
        Query q = sess.createQuery("from Employees");
        q.setMaxResults(10);
        List emp = q.list();
        for (Iterator it = emp.iterator(); it.hasNext();) {
            Employees e = (Employees) it.next();
            String tmp = String.format("Nama: %s %s - Tgl. Lahir: %s",
                    e.getFirstName(), e.getLastName(),
                    e.getBirthDate().toString());
            System.out.println(tmp);
        }
        sess.disconnect();
    }

    public static void showEmpTitles(Session sess, int empId) {
        Employees emp = (Employees) sess.get(Employees.class, empId);
        if (emp != null) {
            System.out.println(String.format("Below is the titles of employee %d: \n", emp.getEmpNo()));
            for (Iterator it = emp.getListOfTitles().iterator(); it.hasNext();) {
                Titles title = (Titles) it.next();
                System.out.println(String.format("From: %s to %s worked as %s",
                        title.getFromDate().toString(),
                        title.getToDate().toString(),
                        title.getTitle()));
            }
        } else {
            System.out.println("Employee not found with ID: " + empId);
        }
        sess.disconnect();
    }

    public static void insertEmployee(Session sess) {
        Employees emp = new Employees();
        emp.setEmpNo(1001);
        emp.setFirstName("Ronaldo");
        emp.setLastName("Simanjuntak");
        emp.setGender("F");
        emp.setBirthDate(new Date(19980103));
        emp.setHireDate(new Date(20080103));
        sess.beginTransaction();
        sess.save(emp);
        sess.getTransaction().commit();
        sess.disconnect();
    }

    public static void updateEmployee(Session sess) {
        Employees emp = new Employees();
        emp.setEmpNo(1001);
        emp.setFirstName("Rahel");
        emp.setLastName("Sagala");
        emp.setGender("M");
        emp.setBirthDate(new Date(19980103));
        emp.setHireDate(new Date(20080103));
        sess.beginTransaction();
        sess.update(emp);
        sess.getTransaction().commit();
        sess.disconnect();
    }

    public static void deleteEmployee(Session sess) {
        Employees emp = new Employees();
        emp.setEmpNo(1001);
        sess.beginTransaction();
        sess.delete(emp);
        sess.getTransaction().commit();
        sess.disconnect();
    }
}
